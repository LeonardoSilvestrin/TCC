helloworld_rx.cpp
==========================

.. literalinclude:: ../../../../examples_RPi/helloworld_rx.cpp
    :caption: examples_RPi/helloworld_rx.cpp
    :linenos:
