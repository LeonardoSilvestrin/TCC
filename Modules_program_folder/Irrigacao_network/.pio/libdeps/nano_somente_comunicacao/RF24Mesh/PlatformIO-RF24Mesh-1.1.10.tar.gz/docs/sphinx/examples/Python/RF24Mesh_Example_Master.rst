RF24Mesh_Example_Master.py
===========================

.. literalinclude:: ../../../../examples_RPi/RF24Mesh_Example_Master.py
    :language: python
    :caption: examples_RPi/RF24Mesh_Example_Master.py
    :linenos:
