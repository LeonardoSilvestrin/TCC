RF24Mesh_Example.py
===========================

.. literalinclude:: ../../../../examples_RPi/RF24Mesh_Example.py
    :language: python
    :caption: examples_RPi/RF24Mesh_Example.py
    :linenos:
