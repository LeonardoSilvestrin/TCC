RF24Mesh_SerialConfig.ino
=========================

.. literalinclude:: ../../../../examples/RF24Mesh_SerialConfig/RF24Mesh_SerialConfig.ino
    :linenos:
